
# Nelnet Data Analysis Project


```python
# Importing necessary libraries

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.impute import SimpleImputer
from tabulate import tabulate
from statsmodels.graphics.tsaplots import plot_acf # Plotting seasonality
```


```python
# Loading the dataset

file_path = "C:/Users/nivar/OneDrive/Desktop/approved_data_2016_2018.csv"
df = pd.read_csv(file_path)

# Displaying the first few rows of the dataset to understand its structure
print(df.head())
```

    C:\Users\nivar\Anaconda3\lib\site-packages\IPython\core\interactiveshell.py:2785: DtypeWarning: Columns (19,50,51,52) have mixed types.Specify dtype option on import or set low_memory=False.
      interactivity=interactivity, compiler=compiler, result=result)
    

       Unnamed: 0         id  loan_amnt  funded_amnt  funded_amnt_inv        term  \
    0      421097  130954621     5000.0       5000.0           5000.0   36 months   
    1      421098  130964697    15000.0      15000.0          15000.0   36 months   
    2      421099  130955326    11200.0      11200.0          11200.0   60 months   
    3      421100  130504052    25000.0      25000.0          25000.0   60 months   
    4      421101  130956066     3000.0       3000.0           3000.0   36 months   
    
       int_rate  installment grade sub_grade  ... chargeoff_within_12_mths  \
    0     20.39       186.82     D        D4  ...                      1.0   
    1      9.92       483.45     B        B2  ...                      0.0   
    2     30.79       367.82     G        G1  ...                      0.0   
    3     21.85       688.35     D        D5  ...                      0.0   
    4      7.34        93.10     A        A4  ...                      0.0   
    
      delinq_amnt disbursement_method  debt_settlement_flag  \
    0         0.0                Cash                     N   
    1         0.0                Cash                     N   
    2         0.0                Cash                     N   
    3         0.0                Cash                     N   
    4         0.0                Cash                     N   
    
      debt_settlement_flag_date settlement_status settlement_date  \
    0                       NaN               NaN             NaN   
    1                       NaN               NaN             NaN   
    2                       NaN               NaN             NaN   
    3                       NaN               NaN             NaN   
    4                       NaN               NaN             NaN   
    
      settlement_amount settlement_percentage settlement_term  
    0               NaN                   NaN             NaN  
    1               NaN                   NaN             NaN  
    2               NaN                   NaN             NaN  
    3               NaN                   NaN             NaN  
    4               NaN                   NaN             NaN  
    
    [5 rows x 56 columns]
    


```python
# Exploring the dataset

# Checking the dimensions of the dataset
print("Shape of the dataset is:", df.shape)

# Checking the data types and missing values
print(df.info())

# Checking summary statistics for numerical columns
print(df.describe())

# Checking unique values and value counts for categorical columns
df.nunique()
```

    Shape of the dataset is: (1373228, 56)
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1373228 entries, 0 to 1373227
    Data columns (total 56 columns):
     #   Column                     Non-Null Count    Dtype  
    ---  ------                     --------------    -----  
     0   Unnamed: 0                 1373228 non-null  int64  
     1   id                         1373228 non-null  int64  
     2   loan_amnt                  1373228 non-null  float64
     3   funded_amnt                1373228 non-null  float64
     4   funded_amnt_inv            1373228 non-null  float64
     5   term                       1373228 non-null  object 
     6   int_rate                   1373228 non-null  float64
     7   installment                1373228 non-null  float64
     8   grade                      1373228 non-null  object 
     9   sub_grade                  1373228 non-null  object 
     10  emp_title                  1257732 non-null  object 
     11  emp_length                 1271156 non-null  object 
     12  home_ownership             1373228 non-null  object 
     13  annual_inc                 1373228 non-null  float64
     14  verification_status        1373228 non-null  object 
     15  issue_d                    1373228 non-null  object 
     16  loan_status                1373228 non-null  object 
     17  pymnt_plan                 1373228 non-null  object 
     18  url                        1373228 non-null  object 
     19  desc                       23 non-null       object 
     20  purpose                    1373228 non-null  object 
     21  title                      1350055 non-null  object 
     22  zip_code                   1373227 non-null  object 
     23  addr_state                 1373228 non-null  object 
     24  dti                        1371519 non-null  float64
     25  delinq_2yrs                1373228 non-null  float64
     26  earliest_cr_line           1373228 non-null  object 
     27  fico_range_low             1373228 non-null  float64
     28  fico_range_high            1373228 non-null  float64
     29  inq_last_6mths             1373227 non-null  float64
     30  mths_since_last_delinq     669068 non-null   float64
     31  mths_since_last_record     222092 non-null   float64
     32  open_acc                   1373228 non-null  float64
     33  pub_rec                    1373228 non-null  float64
     34  revol_bal                  1373228 non-null  float64
     35  revol_util                 1371928 non-null  float64
     36  total_acc                  1373228 non-null  float64
     37  last_pymnt_d               1371471 non-null  object 
     38  last_pymnt_amnt            1373228 non-null  float64
     39  next_pymnt_d               854522 non-null   object 
     40  policy_code                1373228 non-null  float64
     41  application_type           1373228 non-null  object 
     42  annual_inc_joint           120199 non-null   float64
     43  dti_joint                  120197 non-null   float64
     44  verification_status_joint  115219 non-null   object 
     45  acc_now_delinq             1373228 non-null  float64
     46  chargeoff_within_12_mths   1373228 non-null  float64
     47  delinq_amnt                1373228 non-null  float64
     48  disbursement_method        1373228 non-null  object 
     49  debt_settlement_flag       1373228 non-null  object 
     50  debt_settlement_flag_date  16245 non-null    object 
     51  settlement_status          16245 non-null    object 
     52  settlement_date            16245 non-null    object 
     53  settlement_amount          16245 non-null    float64
     54  settlement_percentage      16245 non-null    float64
     55  settlement_term            16245 non-null    float64
    dtypes: float64(28), int64(2), object(26)
    memory usage: 586.7+ MB
    None
             Unnamed: 0            id     loan_amnt   funded_amnt  \
    count  1.373228e+06  1.373228e+06  1.373228e+06  1.373228e+06   
    mean   1.280918e+06  1.112503e+08  1.523548e+04  1.523546e+04   
    std    5.775330e+05  2.362251e+07  9.642011e+03  9.642012e+03   
    min    4.210970e+05  5.571600e+04  1.000000e+03  1.000000e+03   
    25%    7.644098e+05  9.112830e+07  8.000000e+03  8.000000e+03   
    50%    1.107720e+06  1.149927e+08  1.280000e+04  1.280000e+04   
    75%    1.729202e+06  1.321976e+08  2.000000e+04  2.000000e+04   
    max    2.260698e+06  1.456473e+08  4.000000e+04  4.000000e+04   
    
           funded_amnt_inv      int_rate   installment    annual_inc  \
    count     1.373228e+06  1.373228e+06  1.373228e+06  1.373228e+06   
    mean      1.523092e+04  1.299434e+01  4.516974e+02  7.990928e+04   
    std       9.640536e+03  5.099198e+00  2.808786e+02  1.348839e+05   
    min       7.250000e+02  5.310000e+00  7.610000e+00  0.000000e+00   
    25%       8.000000e+03  9.440000e+00  2.465900e+02  4.700000e+04   
    50%       1.280000e+04  1.199000e+01  3.758500e+02  6.600000e+04   
    75%       2.000000e+04  1.577000e+01  6.082200e+02  9.500000e+04   
    max       4.000000e+04  3.099000e+01  1.719830e+03  1.100000e+08   
    
                    dti   delinq_2yrs  ...  last_pymnt_amnt  policy_code  \
    count  1.371519e+06  1.373228e+06  ...     1.373228e+06    1373228.0   
    mean   1.927035e+01  3.019936e-01  ...     2.909615e+03          1.0   
    std    1.688272e+01  8.704100e-01  ...     5.878491e+03          0.0   
    min   -1.000000e+00  0.000000e+00  ...     0.000000e+00          1.0   
    25%    1.188000e+01  0.000000e+00  ...     2.907600e+02          1.0   
    50%    1.796000e+01  0.000000e+00  ...     5.175100e+02          1.0   
    75%    2.488000e+01  0.000000e+00  ...     1.280010e+03          1.0   
    max    9.990000e+02  5.800000e+01  ...     4.219205e+04          1.0   
    
           annual_inc_joint      dti_joint  acc_now_delinq  \
    count      1.201990e+05  120197.000000    1.373228e+06   
    mean       1.236826e+05      19.255805    3.603189e-03   
    std        7.423405e+04       7.824521    6.390568e-02   
    min        5.693510e+03       0.000000    0.000000e+00   
    25%        8.350000e+04      13.530000    0.000000e+00   
    50%        1.100000e+05      18.850000    0.000000e+00   
    75%        1.480000e+05      24.630000    0.000000e+00   
    max        7.874821e+06      69.490000    7.000000e+00   
    
           chargeoff_within_12_mths   delinq_amnt  settlement_amount  \
    count              1.373228e+06  1.373228e+06       16245.000000   
    mean               8.177812e-03  1.324123e+01        5364.492321   
    std                1.030551e-01  7.644211e+02        3938.934339   
    min                0.000000e+00  0.000000e+00         161.000000   
    25%                0.000000e+00  0.000000e+00        2342.120000   
    50%                0.000000e+00  0.000000e+00        4364.000000   
    75%                0.000000e+00  0.000000e+00        7358.000000   
    max                9.000000e+00  2.499250e+05       28503.000000   
    
           settlement_percentage  settlement_term  
    count           16245.000000     16245.000000  
    mean               48.652374        15.594583  
    std                 6.635650         7.144703  
    min                 0.650000         0.000000  
    25%                45.000000        12.000000  
    50%                45.010000        18.000000  
    75%                50.000000        20.000000  
    max               100.000000       181.000000  
    
    [8 rows x 30 columns]
    




    Unnamed: 0                   1373228
    id                           1373228
    loan_amnt                       1561
    funded_amnt                     1561
    funded_amnt_inv                 1580
    term                               2
    int_rate                         241
    installment                    73590
    grade                              7
    sub_grade                         35
    emp_title                     279456
    emp_length                        11
    home_ownership                     5
    annual_inc                     63131
    verification_status                3
    issue_d                           36
    loan_status                        7
    pymnt_plan                         2
    url                          1373228
    desc                              18
    purpose                           14
    title                             14
    zip_code                         928
    addr_state                        50
    dti                            10839
    delinq_2yrs                       35
    earliest_cr_line                 726
    fico_range_low                    38
    fico_range_high                   38
    inq_last_6mths                     6
    mths_since_last_delinq           167
    mths_since_last_record           128
    open_acc                          88
    pub_rec                           36
    revol_bal                      88769
    revol_util                      1250
    total_acc                        144
    last_pymnt_d                      39
    last_pymnt_amnt               391109
    next_pymnt_d                       4
    policy_code                        1
    application_type                   2
    annual_inc_joint               17539
    dti_joint                       4017
    verification_status_joint          3
    acc_now_delinq                     7
    chargeoff_within_12_mths          10
    delinq_amnt                     1915
    disbursement_method                2
    debt_settlement_flag               2
    debt_settlement_flag_date         29
    settlement_status                  3
    settlement_date                   34
    settlement_amount              11891
    settlement_percentage            780
    settlement_term                   36
    dtype: int64




```python
# Counting the number of null values in each column
null_values = df.isnull().sum()
print(null_values)
```

    Unnamed: 0                         0
    id                                 0
    loan_amnt                          0
    funded_amnt                        0
    funded_amnt_inv                    0
    term                               0
    int_rate                           0
    installment                        0
    grade                              0
    sub_grade                          0
    emp_title                     115496
    emp_length                    102072
    home_ownership                     0
    annual_inc                         0
    verification_status                0
    issue_d                            0
    loan_status                        0
    pymnt_plan                         0
    url                                0
    desc                         1373205
    purpose                            0
    title                          23173
    zip_code                           1
    addr_state                         0
    dti                             1709
    delinq_2yrs                        0
    earliest_cr_line                   0
    fico_range_low                     0
    fico_range_high                    0
    inq_last_6mths                     1
    mths_since_last_delinq        704160
    mths_since_last_record       1151136
    open_acc                           0
    pub_rec                            0
    revol_bal                          0
    revol_util                      1300
    total_acc                          0
    last_pymnt_d                    1757
    last_pymnt_amnt                    0
    next_pymnt_d                  518706
    policy_code                        0
    application_type                   0
    annual_inc_joint             1253029
    dti_joint                    1253031
    verification_status_joint    1258009
    acc_now_delinq                     0
    chargeoff_within_12_mths           0
    delinq_amnt                        0
    disbursement_method                0
    debt_settlement_flag               0
    debt_settlement_flag_date    1356983
    settlement_status            1356983
    settlement_date              1356983
    settlement_amount            1356983
    settlement_percentage        1356983
    settlement_term              1356983
    dtype: int64
    

# Data Preprocessing and Data Tidying


```python
# Dropping unnecessary and irrelevant columns and storing the selected columns in a new dataframe
columns_to_drop = ['emp_title', 'desc', 'mths_since_last_delinq', 'mths_since_last_record', 'last_pymnt_d', 'next_pymnt_d', 'annual_inc_joint', 'dti_joint', 'verification_status_joint', 'debt_settlement_flag_date', 'settlement_status', 'settlement_date', 'settlement_amount', 'settlement_percentage', 'settlement_term']
new_df = df.drop(columns=columns_to_drop)

# Converting 'emp_length' to string type
new_df['emp_length'] = new_df['emp_length'].astype(str)

# Extracting numeric values from the 'emp_length' column
new_df['emp_length'] = new_df['emp_length'].str.extract('(\d+)').astype(float)

# Converting 'term' column to string type and then removing "months" and converting to numeric
new_df['term'] = new_df['term'].astype(str).str.replace('months', '').astype(int)

# Imputing missing values in 'emp_length', 'dti', and 'revol_util' using median strategy
imputer = SimpleImputer(strategy='median')
new_df[['emp_length', 'dti', 'revol_util']] = imputer.fit_transform(new_df[['emp_length', 'dti', 'revol_util']])
print (new_df.head())

# Substituting empty cells in the 'title' column with "Other"
new_df['title'] = new_df['title'].fillna("Other")

# Removing rows with empty cells in the specified columns
new_df = new_df.dropna(subset=['zip_code', 'inq_last_6mths'])

# Counting the number of null values in each column
null_values = new_df.isnull().sum()
print(null_values)
```

       Unnamed: 0         id  loan_amnt  funded_amnt  funded_amnt_inv  term  \
    0      421097  130954621     5000.0       5000.0           5000.0    36   
    1      421098  130964697    15000.0      15000.0          15000.0    36   
    2      421099  130955326    11200.0      11200.0          11200.0    60   
    3      421100  130504052    25000.0      25000.0          25000.0    60   
    4      421101  130956066     3000.0       3000.0           3000.0    36   
    
       int_rate  installment grade sub_grade  ...  revol_util total_acc  \
    0     20.39       186.82     D        D4  ...        23.2      18.0   
    1      9.92       483.45     B        B2  ...        46.3      53.0   
    2     30.79       367.82     G        G1  ...        24.6      14.0   
    3     21.85       688.35     D        D5  ...        98.4      16.0   
    4      7.34        93.10     A        A4  ...         0.5      30.0   
    
       last_pymnt_amnt policy_code application_type acc_now_delinq  \
    0           186.82         1.0       Individual            0.0   
    1           483.45         1.0       Individual            0.0   
    2           367.82         1.0        Joint App            0.0   
    3           688.35         1.0       Individual            0.0   
    4           614.03         1.0       Individual            0.0   
    
      chargeoff_within_12_mths delinq_amnt disbursement_method  \
    0                      1.0         0.0                Cash   
    1                      0.0         0.0                Cash   
    2                      0.0         0.0                Cash   
    3                      0.0         0.0                Cash   
    4                      0.0         0.0                Cash   
    
      debt_settlement_flag  
    0                    N  
    1                    N  
    2                    N  
    3                    N  
    4                    N  
    
    [5 rows x 41 columns]
    Unnamed: 0                  0
    id                          0
    loan_amnt                   0
    funded_amnt                 0
    funded_amnt_inv             0
    term                        0
    int_rate                    0
    installment                 0
    grade                       0
    sub_grade                   0
    emp_length                  0
    home_ownership              0
    annual_inc                  0
    verification_status         0
    issue_d                     0
    loan_status                 0
    pymnt_plan                  0
    url                         0
    purpose                     0
    title                       0
    zip_code                    0
    addr_state                  0
    dti                         0
    delinq_2yrs                 0
    earliest_cr_line            0
    fico_range_low              0
    fico_range_high             0
    inq_last_6mths              0
    open_acc                    0
    pub_rec                     0
    revol_bal                   0
    revol_util                  0
    total_acc                   0
    last_pymnt_amnt             0
    policy_code                 0
    application_type            0
    acc_now_delinq              0
    chargeoff_within_12_mths    0
    delinq_amnt                 0
    disbursement_method         0
    debt_settlement_flag        0
    dtype: int64
    


```python
# Selecting specific numerical columns
sel_num_col = new_df[['loan_amnt', 'int_rate', 'annual_inc', 'dti', 'installment']]

# Applying describe function to selected numerical columns
sel_num_stat = sel_num_col.describe()

# Transposing the DataFrame for better readability
sel_num_stat = sel_num_stat.T

# Converting DataFrame to a nicely formatted table
table = tabulate(sel_num_stat, headers='keys', tablefmt='github', numalign='left')
print(table)
```

    |             | count       | mean    | std     | min   | 25%    | 50%    | 75%    | max     |
    |-------------|-------------|---------|---------|-------|--------|--------|--------|---------|
    | loan_amnt   | 1.37323e+06 | 15235.5 | 9642    | 1000  | 8000   | 12800  | 20000  | 40000   |
    | int_rate    | 1.37323e+06 | 12.9943 | 5.0992  | 5.31  | 9.44   | 11.99  | 15.77  | 30.99   |
    | annual_inc  | 1.37323e+06 | 79909.3 | 134884  | 0     | 47000  | 66000  | 95000  | 1.1e+08 |
    | dti         | 1.37323e+06 | 19.2687 | 16.8723 | -1    | 11.89  | 17.96  | 24.87  | 999     |
    | installment | 1.37323e+06 | 451.697 | 280.879 | 7.61  | 246.59 | 375.85 | 608.22 | 1719.83 |
    


```python
# How is loan volume changing over time? Is there any seasonality to their loan origination? 

# Selecting necessary columns
df1 = new_df[['issue_d', 'loan_amnt']]

# Calculating the IQR for 'loan_amnt'
Q1 = df['loan_amnt'].quantile(0.25)
Q3 = df['loan_amnt'].quantile(0.75)
IQR = Q3 - Q1

# Calculating the lower and upper bounds for outliers in 'loan_amnt'
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
print("Lower bound is:", lower_bound)
print("Upper bound is:", upper_bound)

# Converting date columns to datetime format
df1['issue_d'] = pd.to_datetime(df1['issue_d'])

# Grouping by issue date and calculating loan volume
loan_volume = df1.groupby(df1['issue_d'].dt.to_period('M')).sum()

# Plotting loan volume over time
loan_volume.plot(kind='line', figsize=(10, 6))
plt.xlabel('Issue Date')
plt.ylabel('Loan Volume')
plt.title('Loan Volume Over Time')
plt.show()

# Based on the below graph, the general direction of the loan volume graph (overall trend in loan volume) over time is increasing. 
# So it has positive secular trend and  indicates growing demand for loans. There is no clear seasonality pattern in the loan 
# origination since there isn't a regular gap between all of these peaks and troughs and the time that they are accuring isn't 
# regular. So this variation is cyclic because although it's doing sth over and over and it's got a pattern to it but there isn't
# an even space between each one. So there isn't a probability to when these ups and downs are going to occur.
# There is one significant peak (unusual spike) in loan volume in March 2016 that deviate significantly from the overall trend 
# may indicates periods of increased loan demand, such as during holidays, promotions, or specific economic conditions or 
# outliers.
```

    Lower bound is: -10000.0
    Upper bound is: 38000.0
    

    C:\Users\nivar\Anaconda3\lib\site-packages\ipykernel_launcher.py:18: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
    


![png](output_8_2.png)



```python
# Computing and plotting the autocorrelation function (ACF)
plt.figure(figsize=(10, 6))
plot_acf(loan_volume, lags=35)  # Assuming yearly seasonality, plot ACF up to lag 35
plt.title('Autocorrelation Function (ACF) for Loan Volume')
plt.xlabel('Lag (Months)')
plt.ylabel('Autocorrelation')
plt.grid(True)
plt.show()

# In the ACF (autocorrelation function) plot, since we don't observe significant peaks or spikes at regular intervals (lags), it 
# suggests the absence of seasonality or periodic patterns in the data.
```


    <Figure size 720x432 with 0 Axes>



![png](output_9_1.png)



```python
# This company assigns loan grades (A-G) to each loan. Is their grading system indicative of performance? Why/why not?

df2 = new_df[['grade', 'loan_amnt', 'term', 'int_rate', 'installment', 'annual_inc', 'dti', 'loan_status']]

# calculating summary statistics for each loan grade and performance metric
# Grouping by loan grade and calculating mean performance metrics
grade_performance = df2.groupby('grade').mean()
print(grade_performance) # Mean performance metrics for each loan grade

# The interest rate tends to increase as the loan grade decreases. Grade A loans have the lowest mean interest rate (around 7%),
# while grade G loans have the highest (around 30%).
# The term of the loans also tends to increase as the loan grade decreases. Grade A loans have the shortest mean term (around 37
# months), while grade G loans have the longest (around 54 months).
# There isn't a significant variation in mean employment length across different loan grades. However, there seems to be a slight
# decrease as loan grades go from A to G.
# Annual Income (annual_inc): There's a decreasing trend in mean annual income as loan grades worsen. Grade A loans have the 
# highest mean annual income (around $91,443), while grade G loans have the lowest (around $71,410).
# Debt-to-Income Ratio (dti): The debt-to-income ratio tends to increase as the loan grade decreases. Grade A loans have the 
# lowest mean DTI (around 16.58), while grade G loans have the highest (around 25.09).
# In conclusion, lower loan grades (such as grades D through G) are associated with higher interest rates, longer loan terms, 
# lower annual incomes, and higher debt-to-income ratios compared to higher loan grades (such as grades A and B). This analysis 
# suggests a clear pattern where riskier loan grades come with higher costs and potentially greater financial strain on borrowers.
```

              loan_amnt       term   int_rate  installment    annual_inc  \
    grade                                                                  
    A      14897.010041  37.572277   7.002007   443.178211  91442.998676   
    B      14503.448630  41.053577  10.580400   420.178912  80884.790311   
    C      15386.152829  44.714133  14.244141   445.272614  76095.096444   
    D      15902.508925  46.043339  18.875462   491.117678  72435.577219   
    E      16859.441801  49.300314  23.938038   541.897156  71568.603128   
    F      19107.346275  54.560290  27.760730   621.501198  71247.219987   
    G      20256.954634  54.911813  30.091657   689.127678  71409.571415   
    
                 dti  
    grade             
    A      16.584468  
    B      18.378011  
    C      20.036710  
    D      21.749805  
    E      22.861974  
    F      23.937051  
    G      25.092969  
    


```python
# we can visualize the relationship between loan grades and performance metrics using bar plots:

# Defining the desired order of loan grade categories
desired_order = ["A", "B", "C", "D", "E", "F", "G"]

# Reindexing the DataFrame to reorder the rows according to the desired order
grade_performance_ordered = grade_performance.reindex(desired_order)

# Plotting the grouped bar plot
plt.figure(figsize=(12, 6))

# Defining the numerical variables to be plotted
numerical_vars = ['loan_amnt', 'term', 'int_rate', 'installment', 'annual_inc', 'dti']

# Looping through each numerical variable and plotting a grouped bar
for i, var in enumerate(numerical_vars):
    plt.subplot(2, 3, i+1)
    sns.barplot(data=df2, x='grade', y=var, ci=None, palette='viridis', order=desired_order)
    plt.title(f'{var} vs Loan Grade')
    plt.xlabel('Loan Grade')
    plt.ylabel(var)
    plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

# We can confirm our result with below visualizations as well that lower loan grades (such as grades D through G) are associated 
# with higher loan amount, longer loan terms, higher interest rates, higher installment, lower annual incomes, and higher dti
# ratios compared to higher loan grades (such as grades A and B)
```


![png](output_11_0.png)



```python
# Outside of loan grade, what else would you say are borrower characteristics that affect loan performance?

df3 = new_df[['term', 'int_rate', 'annual_inc', 'loan_status', 'emp_length']]

# calculating summary statistics for each loan status and performance metric
# Groupping by loan status and calculating mean performance metrics
grade_performance = df3.groupby('loan_status').mean()

# Defining the desired order of loan status categories
desired_order = ["Fully Paid", "Current", "In Grace Period", "Late (16-30 days)", "Late (31-120 days)", "Charged Off", "Default"]

# Reindexing the DataFrame to reorder the rows according to the desired order
grade_performance_ordered = grade_performance.reindex(desired_order)
print(grade_performance_ordered) # Mean performance metrics for each loan status
```

                             term   int_rate    annual_inc  emp_length
    loan_status                                                       
    Fully Paid          40.626855  12.634819  80813.859042    6.068635
    Current             43.478231  12.645205  80565.025435    5.955643
    In Grace Period     44.809130  15.373433  80961.317998    5.850846
    Late (16-30 days)   44.748561  15.349992  79116.533570    5.721541
    Late (31-120 days)  44.931870  15.612593  76880.340042    5.764301
    Charged Off         44.042871  16.027511  72610.810965    5.851261
    Default             44.210526  16.152368  73422.947368    5.236842
    


```python
# Defining the desired order of loan status categories
desired_order = ["Fully Paid", "Current", "In Grace Period", "Late (16-30 days)", "Late (31-120 days)", "Charged Off", "Default"]

# Reindexing the DataFrame to reorder the rows according to the desired order
grade_performance_ordered = grade_performance.reindex(desired_order)

# Plotting the grouped bar plot
plt.figure(figsize=(12, 7))

# Defining the numerical variables to be plotted
numerical_vars = ['int_rate', 'term', 'annual_inc', 'emp_length']

# Preprocessing 'emp_length' column to remove the 'year' suffix and converting to numerical values
df3['emp_length'] = df3['emp_length'].astype(str).str.replace(' years', '').str.replace(' year', '').astype(float)

# Looping through each numerical variable and plotting a grouped bar
for i, var in enumerate(numerical_vars):
    plt.subplot(2, 2, i+1)
    sns.barplot(data=df3, x='loan_status', y=var, ci=None, palette='viridis', order=desired_order)
    plt.title(f'{var} vs Loan Status')
    plt.xlabel('Loan Status')
    plt.ylabel(var)
    plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

# So, loan status is the other factor that can affect loan performance (interest rate, term, employment length, annual income)
# These results reveal the relationship between loan status and various loan performance metrics, showcasing both positive and 
# negative associations. For instance, lower interest rates and longer employment lengths are generally associated with positive 
# loan outcomes, such as 'Fully Paid' and 'Current' statuses. Additionally, higher annual incomes are typically linked with 
# favorable loan statuses, indicating greater financial stability and repayment capacity. 
```

    C:\Users\nivar\Anaconda3\lib\site-packages\ipykernel_launcher.py:14: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      
    


![png](output_13_1.png)


# Exploratory Data Analysis


```python
# Loan Amount and Interest Rate Distributions

# Setting seaborn style to "darkgrid"
sns.set_style("darkgrid")

# Creating a figure and two subplots arranged horizontally
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Plotting the distribution of loan amounts
sns.distplot(new_df.loan_amnt, ax=axes[0])
axes[0].set_title("Distribution of Loan Amount")

# Plotting the distribution of interest rates
sns.distplot(new_df.int_rate, ax=axes[1])
axes[1].set_title("Distribution of Interest Rate")

# Adjusting layout
plt.tight_layout()
plt.show()

# The loan amount graph exhibits a prominent peak at $10,000, followed by a gradual decline in the curve. This pattern implies a 
# lower preference among investors for larger loan amounts, with a predominant focus on smaller to mid-range loan investments.
# In the loan interest distribution, a notable concentration of investors is observed within the 10 to 15% interest rate range. 
# Beyond this range, there is a gradual decrease in the number of investors, indicating a preference for lower interest rates 
# among the majority of borrowers.
```

    C:\Users\nivar\Anaconda3\lib\site-packages\seaborn\distributions.py:2619: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    C:\Users\nivar\Anaconda3\lib\site-packages\matplotlib\cbook\__init__.py:2062: FutureWarning: Support for multi-dimensional indexing (e.g. `obj[:, None]`) is deprecated and will be removed in a future version.  Convert to a numpy array before indexing instead.
      x[:, None]
    C:\Users\nivar\Anaconda3\lib\site-packages\matplotlib\axes\_base.py:248: FutureWarning: Support for multi-dimensional indexing (e.g. `obj[:, None]`) is deprecated and will be removed in a future version.  Convert to a numpy array before indexing instead.
      x = x[:, np.newaxis]
    C:\Users\nivar\Anaconda3\lib\site-packages\matplotlib\axes\_base.py:250: FutureWarning: Support for multi-dimensional indexing (e.g. `obj[:, None]`) is deprecated and will be removed in a future version.  Convert to a numpy array before indexing instead.
      y = y[:, np.newaxis]
    C:\Users\nivar\Anaconda3\lib\site-packages\seaborn\distributions.py:2619: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    C:\Users\nivar\Anaconda3\lib\site-packages\matplotlib\cbook\__init__.py:2062: FutureWarning: Support for multi-dimensional indexing (e.g. `obj[:, None]`) is deprecated and will be removed in a future version.  Convert to a numpy array before indexing instead.
      x[:, None]
    C:\Users\nivar\Anaconda3\lib\site-packages\matplotlib\axes\_base.py:248: FutureWarning: Support for multi-dimensional indexing (e.g. `obj[:, None]`) is deprecated and will be removed in a future version.  Convert to a numpy array before indexing instead.
      x = x[:, np.newaxis]
    C:\Users\nivar\Anaconda3\lib\site-packages\matplotlib\axes\_base.py:250: FutureWarning: Support for multi-dimensional indexing (e.g. `obj[:, None]`) is deprecated and will be removed in a future version.  Convert to a numpy array before indexing instead.
      y = y[:, np.newaxis]
    


![png](output_15_1.png)



```python
# Loan Status Distribution

# Groupping loans by their status and counting the number of loans in each status category
loan_status = new_df.groupby('loan_status')['loan_status'].count()

# Generating the pie chart with loan status counts
plt.figure(figsize=(10,10))
plt.title('Loans Status', fontsize=15)
pie = plt.pie(loan_status, autopct='%1.1f%%',labels=loan_status.index ,startangle=180)
# Making the numbers inside the pies bold
for text in pie[1]:
    text.set_fontweight('bold')
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle
# Making the labels bold
plt.setp(pie[1], fontweight='bold')
loan_status

# The distribution suggests that a significant number of loans are still in progress ("Current"), while a notable portion has 
# been fully paid. However, there are also instances of delinquency ("Late (16-30 days)", "Late (31-120 days)", "In Grace Period")
# and a small number of defaults. This indicates successful investment outcomes for a significant portion of investors.
```




    loan_status
    Charged Off           116257
    Current               823093
    Default                   38
    Fully Paid            402447
    In Grace Period         7623
    Late (16-30 days)       3997
    Late (31-120 days)     19771
    Name: loan_status, dtype: int64




![png](output_16_1.png)



```python
# Loan Distributions by Purposes and States

# Loan Purpose Distribution
loan_purpose_counts = new_df['purpose'].value_counts()
plt.figure(figsize=(18, 6))

# Plotting Loan Purpose Distribution
plt.subplot(1, 2, 1)
loan_purpose_counts.plot(kind='bar', color='skyblue')
plt.title('Distribution of Loan Purposes', fontsize=15)
plt.xlabel('Loan Purpose', fontsize=15)
plt.ylabel('Frequency', fontsize=15)
plt.xticks(rotation=45, ha='right', fontsize=12)  # Increasing font size for x-axis ticks
plt.yticks(fontsize=12)  # Increasing font size for y-axis ticks

# Geographic Distribution Analysis
loan_counts_by_state = new_df['addr_state'].value_counts()

# Plotting Geographic Distribution Analysis
plt.subplot(1, 2, 2)
loan_counts_by_state.plot(kind='bar', color='lightgreen')
plt.title('Loan Distribution by State', fontsize=15)
plt.xlabel('State', fontsize=15)
plt.ylabel('Number of Loans', fontsize=15)
plt.xticks(rotation=90, fontsize=11)  # Increasing font size for x-axis ticks and rotate labels
plt.yticks(fontsize=12)  # Increasing font size for y-axis ticks
plt.tight_layout()  # Adjusting layout to prevent overlap
plt.show()

# The frequency distribution of loan purposes was calculated, revealing that the most common reasons borrowers seek loans are 
# debt consolidation and credit card, respectively.
# I explored the geographic distribution of loan originations to identify regions with the highest loan activity. The states with
# the highest loan activity are California, Texas, New York, and Florida, respectively.
```


![png](output_17_0.png)



```python
# Calculating correlation matrix
corr_matrix = df2.corr()

# Plotting correlation heatmap
plt.figure(figsize=(12, 10))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Heatmap of Features')
plt.show()

# A strong correlation is observed between installment vs loan amount.
# Correlation heatmap helps to visualize the relationships between variables, detecting pattern and feature selection by removing
# highly correlated variables.
```


![png](output_18_0.png)

